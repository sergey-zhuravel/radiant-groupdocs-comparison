Radiant.config do |config|
  # config.define "setting.name", :default => 'value', :select_from => ['foo', 'bar']
end
