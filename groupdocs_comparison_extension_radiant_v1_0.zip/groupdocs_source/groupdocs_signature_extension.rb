# Uncomment this if you reference any of your controllers in activate
# require_dependency "application_controller"
require "radiant-groupdocs_signature-extension"

class GroupdocsSignatureExtension < Radiant::Extension
  version     RadiantGroupdocsSignatureExtension::VERSION
  description RadiantGroupdocsSignatureExtension::DESCRIPTION
  url         RadiantGroupdocsSignatureExtension::URL

  # See your config/routes.rb file in this extension to define custom routes

  extension_config do |config|
    # config is the Radiant.configuration object
  end

  def activate
    Page.send :include, SignatureTags
    # tab 'Content' do
    #   add_item "GroupDocs signature", "/admin/groupdocs_signature", :after => "Pages"
    # end
  end
end
