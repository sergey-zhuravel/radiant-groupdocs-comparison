module SignatureTags
  include Radiant::Taggable

  desc %{
  Free cross browser Document Embedded Signature. Works with all major browsers.
  
  *Usage:*
    
    <pre><code><r:gdsignature id="47d86daacf8bbcd66c1dab0879" width="700" height="400" /></code></pre>
  }
  tag "gdsignature" do |tag|
%{<div class="box">
  <h2>
    <iframe src="https://apps.groupdocs.com/signature/forms/SignEmbed/#{tag.attr['id']}?quality=50&use_pdf=False&download=False&referer=Radiant/1.0" frameborder="0" width="#{tag.attr['width']}" height="#{tag.attr['height']}"></iframe>
  </h2>
  <div class="content">
    #{tag.expand}
  </div>
</div>}
  end
end