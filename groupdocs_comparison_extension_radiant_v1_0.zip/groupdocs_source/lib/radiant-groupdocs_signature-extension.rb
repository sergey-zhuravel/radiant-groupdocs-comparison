module RadiantGroupdocsSignatureExtension
  VERSION     = "1.0.0"
  SUMMARY     = "GroupDocs Signature for Radiant CMS"
  DESCRIPTION = "This plugin allows you to embed your documents meant for signing, complete with GroupDocs digital signature app, to your Radiant webpages."
  URL         = "http://groupdocs.com/apps/signature"
  AUTHORS     = ["GroupDocs Marketplace Team"]
  EMAIL       = ["marketplace@groupdocs.com"]
end
