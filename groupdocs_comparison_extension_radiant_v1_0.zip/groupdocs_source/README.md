radiant-groupdocs-signature-source
==================================

GroupDocs Signature plugin for Radiant CMS (Source code)

###Plugin Installation Instuctions:
1. Unpack plugin and copy groupdocs_signature folder with the plugin to \vendor\extensions
2. For a while we have no data stored in database so we no need to fire migrate and update commands, so when extension is copied to radiant it can be used at the app.
3. Oficial installation instructions - https://github.com/radiant/radiant/wiki/Installing-Extensions
4. To use GD extension - edit page and use gdsignature tag. To check a usage of the tag -  open Available Tags -> Filter Tags and find gdsignature where you can see a description and the Usage of the tag. (Example of the tag <r:gdsignature id="a459272dcfa48cbc5ed8f07ec297f43d21186" width="700" height="500"/>)

### Sign, Manage, Annotate, Assemble, Compare and Convert Documents with GroupDocs
* [Sign documents online with GroupDocs Signature](http://groupdocs.com/apps/signature)
* [Download Radiant Signature plugin package here](https://github.com/groupdocs/radiant-groupdocs-signature)
* [Radiant Assembly on Radiant Extension Directory] (http://ext.radiantcms.org/extensions/300-groupdocs-assembly)

###Created by [GroupDocs Marketplace Team](http://groupdocs.com/marketplace/).
